# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .raw_message_delta_event import RawMessageDeltaEvent

__all__ = ["MessageDeltaEvent"]

MessageDeltaEvent = RawMessageDeltaEvent
"""The RawMessageDeltaEvent type should be used instead"""
